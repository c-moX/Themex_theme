
        <footer>
            <div class="main_footer_section">
                <div class="container-fluid">
                    <div class="row">
					<?php dynamic_sidebar('themx-footer-sidebar');?>
                    </div>
                </div>
            </div>
            <div class="seceond_footer_section text-center"> 
                <h4>© Copyright 2017<span>|</span> Helloxpart By THEMX <span>|</span> All Rights Reserved</h4>
            </div>    
        </footer>
		<?php wp_footer();?>
    </body>
</html>