<form action="<?php echo esc_url( home_url( '/' ));?>" method="get" class="Blog_1-search1">
	<input type="text" name= "s" placeholder= <?php echo esc_attr('Search & Prees Enter','themx');?>>
	<div class="Blog_1-search"> <input type="submit" value="&#xf002;"></div>
</form>
